# SOP: Multi-Agent OCR Comparison System

## Objective
Extract and compare text from images using three OCR engines (Tesseract, Google Vision, AWS Textract) coordinated by a central evaluator agent in ChatGPT.

## Status: ✅ Up to Tool Mapping

See README for architecture and tooling overview.
